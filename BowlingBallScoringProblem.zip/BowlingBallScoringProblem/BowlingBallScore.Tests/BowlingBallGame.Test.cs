using BowlingBallScore.BowlingRules;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BowlingBallScore.Tests
{
    [TestClass]
    public class BowlingBallGame
    {
        [TestMethod]
        public void GutterScoreTest()
        {
            var bowlingMandatoryRules = new BowlingMandatoryRules();
            var bowlingGame = new BowlingGame(bowlingMandatoryRules);
            PinsDownInCurrentRoll(bowlingGame, 0, 20);
            Assert.AreEqual(0, bowlingGame.GetScore());
        }

        [TestMethod]
        public void OnesScoreTest()
        {
            var bowlingMandatoryRules = new BowlingMandatoryRules();
            var bowlingGame = new BowlingGame(bowlingMandatoryRules);
            var totalRolls = bowlingMandatoryRules.MaxFramesCount * 2;
            PinsDownInCurrentRoll(bowlingGame, 1, totalRolls);
            Assert.AreEqual(totalRolls, bowlingGame.GetScore());
        }
        [TestMethod]
        public void OneSpareGameScoreTest()
        {
            var bowlingMandatoryRules = new BowlingMandatoryRules();
            var bowlingGame = new BowlingGame(bowlingMandatoryRules);
            var totalRolls = bowlingMandatoryRules.MaxFramesCount * 2;
            PinsDownInCurrentRoll(bowlingGame, 5, 2);
            PinsDownInCurrentRoll(bowlingGame, 1, totalRolls - 2);
            Assert.AreEqual(29, bowlingGame.GetScore());
        }

        [TestMethod]
        [DataRow(5, 9, 1, 1, 97)]
        public void MultipleConsecutiveSparesScoreTest(int consecutiveSparesCount, int spareFirstAttempt, int spareSecondAttempt, int normalAttempt, int expected)
        {
            var bowlingbowlingMandatoryRules = new BowlingMandatoryRules();
            var bowlingGame = new BowlingGame(bowlingbowlingMandatoryRules);
            var totalAttempts = bowlingbowlingMandatoryRules.MaxFramesCount * 2;

            for (int i = 0; i < consecutiveSparesCount; i++)
            {
                PinsDownInCurrentRoll(bowlingGame, spareFirstAttempt, 1);
                PinsDownInCurrentRoll(bowlingGame, spareSecondAttempt, 1);
            }

            PinsDownInCurrentRoll(bowlingGame, normalAttempt, totalAttempts - (consecutiveSparesCount * 2));
            Assert.AreEqual(expected, bowlingGame.GetScore());
        }

        [TestMethod]
        public void StrikeScoreTest()
        {
            var bowlingMandatoryRules = new BowlingMandatoryRules();
            var bowlingGame = new BowlingGame(bowlingMandatoryRules);
            var totalRolls = bowlingMandatoryRules.MaxFramesCount * 2;
            PinsDownInCurrentRoll(bowlingGame, 10, 1);
            PinsDownInCurrentRoll(bowlingGame, 1, totalRolls - 2);
            Assert.AreEqual(30, bowlingGame.GetScore());
        }

        [TestMethod]
        [DataRow(5, 1, 133)]
        public void MultipleConsecutiveStrikesTest(int consecutiveStrikesCount, int roll, int expected)
        {
            var bowlingMandatoryRules = new BowlingMandatoryRules();
            var bowlingGame = new BowlingGame(bowlingMandatoryRules);
            var totalRolls = bowlingMandatoryRules.MaxFramesCount * 2;

            for (int i = 0; i < consecutiveStrikesCount; i++)
            {
                PinsDownInCurrentRoll(bowlingGame, 10, 1);
            }

            PinsDownInCurrentRoll(bowlingGame, roll, totalRolls - (consecutiveStrikesCount * 2));
            Assert.AreEqual(expected, bowlingGame.GetScore());
        }

        [TestMethod]
        public void StrikeOnEveryGameTest()
        {
            var bowlingMandatoryRules = new BowlingMandatoryRules();
            var bowlingGame = new BowlingGame(bowlingMandatoryRules);

            PinsDownInCurrentRoll(bowlingGame, 10, 12);
            Assert.AreEqual(300, bowlingGame.GetScore());
        }

        [TestMethod]
        public void AllSpareGameTest()
        {
            var bowlingMandatoryRules = new BowlingMandatoryRules();
            var bowlingGame = new BowlingGame(bowlingMandatoryRules);

            PinsDownInCurrentRoll(bowlingGame, 5, 21);
            Assert.AreEqual(150, bowlingGame.GetScore());
        }

        [TestMethod]
        public void SparesAndStrikeTest()
        {
            var bowlingMandatoryRules = new BowlingMandatoryRules();
            var bowlingGame = new BowlingGame(bowlingMandatoryRules);

            PinsDownInCurrentRoll(bowlingGame, 5, 10);
            PinsDownInCurrentRoll(bowlingGame, 10, 7);
            Assert.AreEqual(230, bowlingGame.GetScore());
        }

        [TestMethod]
        public void OneSpareAndOneStrikeTest()
        {
            var bowlingMandatoryRules = new BowlingMandatoryRules();
            var bowlingGame = new BowlingGame(bowlingMandatoryRules);

            PinsDownInCurrentRoll(bowlingGame, 5, 2);
            PinsDownInCurrentRoll(bowlingGame, 10, 1);

            PinsDownInCurrentRoll(bowlingGame, 5, 2);
            PinsDownInCurrentRoll(bowlingGame, 10, 1);

            PinsDownInCurrentRoll(bowlingGame, 5, 2);
            PinsDownInCurrentRoll(bowlingGame, 10, 1);

            PinsDownInCurrentRoll(bowlingGame, 5, 2);
            PinsDownInCurrentRoll(bowlingGame, 10, 1);

            PinsDownInCurrentRoll(bowlingGame, 5, 2);
            PinsDownInCurrentRoll(bowlingGame, 10, 1);
            PinsDownInCurrentRoll(bowlingGame, 5, 2);

            Assert.AreEqual(200, bowlingGame.GetScore());
        }

        [TestMethod]
        public void CompletedGameScoreTest()
        {
            var bowlingGame = new BowlingGame(new BowlingMandatoryRules());
            bowlingGame.PinsDownInCurrentRoll(7);
            bowlingGame.PinsDownInCurrentRoll(2);
            bowlingGame.PinsDownInCurrentRoll(5);
            bowlingGame.PinsDownInCurrentRoll(5);
            bowlingGame.PinsDownInCurrentRoll(3);
            bowlingGame.PinsDownInCurrentRoll(7);
            bowlingGame.PinsDownInCurrentRoll(10);
            bowlingGame.PinsDownInCurrentRoll(10);
            bowlingGame.PinsDownInCurrentRoll(6);
            bowlingGame.PinsDownInCurrentRoll(4);
            bowlingGame.PinsDownInCurrentRoll(10);
            bowlingGame.PinsDownInCurrentRoll(5);
            bowlingGame.PinsDownInCurrentRoll(2);
            bowlingGame.PinsDownInCurrentRoll(10);
            bowlingGame.PinsDownInCurrentRoll(6);
            bowlingGame.PinsDownInCurrentRoll(4);
            bowlingGame.PinsDownInCurrentRoll(10);
            Assert.AreEqual(172, bowlingGame.GetScore());
        }

        [TestMethod]
        public void ScoreValidForCompletedGame()
        {
            var bowlingGame = new BowlingGame(new BowlingMandatoryRules());
            bowlingGame.PinsDownInCurrentRoll(7);
            bowlingGame.PinsDownInCurrentRoll(2);
            bowlingGame.PinsDownInCurrentRoll(5);
            bowlingGame.PinsDownInCurrentRoll(5);
            bowlingGame.PinsDownInCurrentRoll(3);
            bowlingGame.PinsDownInCurrentRoll(7);
            bowlingGame.PinsDownInCurrentRoll(10);
            bowlingGame.PinsDownInCurrentRoll(10);
            bowlingGame.PinsDownInCurrentRoll(6);
            bowlingGame.PinsDownInCurrentRoll(4);
            bowlingGame.PinsDownInCurrentRoll(10);
            bowlingGame.PinsDownInCurrentRoll(5);
            bowlingGame.PinsDownInCurrentRoll(2);
            bowlingGame.PinsDownInCurrentRoll(10);
            bowlingGame.PinsDownInCurrentRoll(6);
            bowlingGame.PinsDownInCurrentRoll(4);
            bowlingGame.PinsDownInCurrentRoll(10);
            Assert.AreEqual(172, bowlingGame.GetScore());
        }

        [TestMethod]
        public void ScoreValidTest2()
        {
            var bowlingGame = new BowlingGame(new BowlingMandatoryRules());
            bowlingGame.PinsDownInCurrentRoll(10);
            bowlingGame.PinsDownInCurrentRoll(9);
            bowlingGame.PinsDownInCurrentRoll(1);
            bowlingGame.PinsDownInCurrentRoll(5);
            bowlingGame.PinsDownInCurrentRoll(5);
            bowlingGame.PinsDownInCurrentRoll(7);
            bowlingGame.PinsDownInCurrentRoll(2);
            bowlingGame.PinsDownInCurrentRoll(10);
            bowlingGame.PinsDownInCurrentRoll(10);
            bowlingGame.PinsDownInCurrentRoll(10);
            bowlingGame.PinsDownInCurrentRoll(9);
            bowlingGame.PinsDownInCurrentRoll(0);
            bowlingGame.PinsDownInCurrentRoll(8);
            bowlingGame.PinsDownInCurrentRoll(2);
            bowlingGame.PinsDownInCurrentRoll(9);
            bowlingGame.PinsDownInCurrentRoll(1);
            bowlingGame.PinsDownInCurrentRoll(10);
            Assert.AreEqual(187, bowlingGame.GetScore());
        }

        private void PinsDownInCurrentRoll(BowlingGame bowlingGame, int pins, int times)
        {
            for (int i = 0; i < times; i++)
            {
                bowlingGame.PinsDownInCurrentRoll(pins);
            }
        }
    }
}
