﻿using BowlingBallScore.Shared;
using System.Collections.Generic;
using System.Linq;

namespace BowlingBallScore.BowlingRules
{
    public class BowlingMandatoryRules : IBowlingMandatoryRules
    {
        public int MaxFramesCount { get; set; } = 10;
        public int MaxPinsDownForLastFrame { get; set; } = 3;
        public int MaxAttemptsPerFrame { get; set; } = 2;
        public int MaxAttemptPerStrike { get; set; } = 1;
        public int SpareBonusPinsDown { get; set; } = 1;
        public int StrikeBonusPinsDown { get; set; } = 2;
        public int TotalPins { get; set; } = 10;

        public FrameType GetFrameType(IEnumerable<int> pins)
        {
            if (IsStrikeFrame(pins))
                return FrameType.Strike;
            else if (IsSpareFrame(pins))
                return FrameType.Spare;
            else
                return FrameType.Open;
        }

        /// <summary>
        /// Check if the current frame is a strike
        /// </summary>
        /// <param name="pins">Pins taken down in the frame</param>
        /// <returns>Returns true if the Strike, else false</returns>
        private bool IsStrikeFrame(IEnumerable<int> pins)
        {
            return pins.First() == TotalPins;
        }

        /// <summary>
        /// Check if the current frame is spare
        /// </summary>
        /// <param name="pins">Pins taken down in the frame</param>
        /// <returns>Returns true if the Spare, else false</returns>
        private bool IsSpareFrame(IEnumerable<int> pins)
        {
            return pins.Count() >= MaxAttemptsPerFrame && pins.Take(MaxAttemptsPerFrame).Sum() == TotalPins;
        }

        public int GetMaxpinsDownAllowedForCurrentFrame(int currentFrame, IEnumerable<int> pins)
        {
            int maxRollsAllowed = MaxAttemptsPerFrame;

            //If current frame is last frame
            if (currentFrame == MaxFramesCount)
            {
                if (IsStrikeFrame(pins) || IsSpareFrame(pins))
                    maxRollsAllowed = MaxPinsDownForLastFrame;
            }
            else
            {
                if (IsStrikeFrame(pins))
                    maxRollsAllowed = MaxAttemptPerStrike;
            }

            return maxRollsAllowed;
        }
    }
}
