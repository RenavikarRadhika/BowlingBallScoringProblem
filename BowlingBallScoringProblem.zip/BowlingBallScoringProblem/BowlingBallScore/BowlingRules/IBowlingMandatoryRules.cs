﻿using BowlingBallScore.Shared;
using System.Collections.Generic;

namespace BowlingBallScore.BowlingRules
{
    // This interface defines the mandatory rules which needs to be followed while palying the game
    public interface IBowlingMandatoryRules
    {
        /// <summary>
        /// Maximum Frames count per game
        /// </summary>
        int MaxFramesCount { get; set; }

        /// <summary>
        /// Maximum pins down count for last Frame
        /// </summary>
        int MaxPinsDownForLastFrame { get; set; }

        /// <summary>
        /// Maximum pins down count per Frame
        /// </summary>
        int MaxAttemptsPerFrame { get; set; }

        /// <summary>
        /// Maximum pins down count per Strike
        /// </summary>
        int MaxAttemptPerStrike { get; set; }

        /// <summary>
        /// Spare Bonus Pins
        /// </summary>
        int SpareBonusPinsDown { get; set; }

        /// <summary>
        /// Strike Bonus Pins
        /// </summary>

        int StrikeBonusPinsDown { get; set; }

        /// <summary>
        /// Total Pins
        /// </summary>
        int TotalPins { get; set; }

        /// <summary>
        /// Get type of the frame
        /// </summary>
        /// <param name="pins">Pins taken down in the frame</param>
        /// <returns>Returns the type of the frame</returns>

        FrameType GetFrameType(IEnumerable<int> pins);

        /// <summary>
        /// Get Maximum Number of pins allowed for the frame
        /// </summary>
        /// <param name="currentFrame">Frame Number</param>
        /// <param name="pins">Pins knocked in the frame</param>
        /// <returns>Maximum pins allowd to be thrown for the current frame</returns>

        int GetMaxpinsDownAllowedForCurrentFrame(int currentFrame, IEnumerable<int> pins);
    }
}
