﻿using System.Collections.Generic;

namespace BowlingBallScore.UserFrames
{
    // This interface represents the frames used in the game
    public interface IUserFrame
    {
        /// <summary>
        /// Gives the current frame number
        /// </summary>
        int FrameNumber { get; }

        /// <summary>
        /// Gives total number of pins taken down in the particular frame
        /// </summary>
        int FrameScore { get; }

        /// <summary>
        /// Returns the succeeding frame in case of Spare/Strike
        /// </summary>
        IUserFrame SucceedingFrame { get; set; }

        /// <summary>
        /// Collection of pins down per attempt in the current frame
        /// </summary>
        IEnumerable<int> PinsDownPerAttempt { get; }

        /// <summary>
        /// Returns the actual score of the frame, including previous scores and bonus
        /// </summary>
        /// <returns></returns>
        int GetGrossFrameScore();
    }
}
