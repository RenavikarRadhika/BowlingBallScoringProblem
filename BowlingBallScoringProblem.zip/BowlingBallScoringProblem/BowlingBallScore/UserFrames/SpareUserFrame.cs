﻿using BowlingBallScore.BowlingRules;
using BowlingBallScore.Shared;
using System.Collections.Generic;

namespace BowlingBallScore.UserFrames
{
    // This class contains the properties and methods related to spare frame
    internal class SpareUserFrame : OpenUserFrame
    {
        private readonly IBowlingMandatoryRules _bowlingMandatoryRules;
        internal SpareUserFrame(IBowlingMandatoryRules bowlingMandatoryRules, int frameNumber, IEnumerable<int> pinsDownPerAttempt) : base(frameNumber, pinsDownPerAttempt)
        {
            _bowlingMandatoryRules = bowlingMandatoryRules;
        }
        public override int GetGrossFrameScore()
        {
            return this.GetBonusScore(_bowlingMandatoryRules.SpareBonusPinsDown, FrameScore);
        }
    }
}
