﻿using System.Collections.Generic;
using System.Linq;

namespace BowlingBallScore.UserFrames
{
    // This class contains the properties and methods related to open frame
    internal class OpenUserFrame : IUserFrame
    {
        internal OpenUserFrame(int frameNumber, IEnumerable<int> pinsDownPerAttempt)
        {
            FrameNumber = frameNumber;
            PinsDownPerAttempt = pinsDownPerAttempt;
        }
        public int FrameNumber { get; }

        public int FrameScore => PinsDownPerAttempt.Sum();

        public IUserFrame SucceedingFrame { get; set; }

        public IEnumerable<int> PinsDownPerAttempt { get; }
        
        public virtual int GetGrossFrameScore()
        {
            return FrameScore;
        }
    }
}
