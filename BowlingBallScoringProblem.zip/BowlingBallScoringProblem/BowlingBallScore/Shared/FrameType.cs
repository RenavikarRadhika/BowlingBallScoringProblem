﻿namespace BowlingBallScore.Shared
{
    // Enum to get the frame type
    public enum FrameType
    {
        Open = 0,
        Spare = 1,
        Strike = 2
    }
}
