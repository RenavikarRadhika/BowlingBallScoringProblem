﻿using BowlingBallScore.UserFrames;

namespace BowlingBallScore.Shared
{
    public static class ScoreCalculator
    {
        public static int GetBonusScore(this IUserFrame frame, int bonusCount, int totalFrameScore, int bonusUsed = 0)
        {
            var succeedingFrame = frame.SucceedingFrame;

            if (succeedingFrame == null)
                return totalFrameScore;

            foreach (var roll in succeedingFrame.PinsDownPerAttempt)
            {
                if (bonusUsed >= bonusCount)
                    break;
                else
                {
                    totalFrameScore += roll;
                    bonusUsed++;
                }
            }

            if (bonusUsed == bonusCount)
                return totalFrameScore;
            else
                return succeedingFrame.GetBonusScore(bonusCount, totalFrameScore, bonusUsed);
        }
    }
}
