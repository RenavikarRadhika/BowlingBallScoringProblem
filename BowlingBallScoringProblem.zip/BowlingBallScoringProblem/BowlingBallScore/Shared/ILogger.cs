﻿namespace BowlingBallScore.Shared
{
    public interface ILogger
    {
        void LogException(string meaage);
    }

    public sealed class LoggerManager : ILogger
    {
        private LoggerManager()
        {

        }

        private static LoggerManager instance = null;

        public static LoggerManager getInstace
        {
            get
            {
                if (instance == null)
                {
                    instance = new LoggerManager();
                }
                return instance;
            }
        }

        public void LogException(string meaage)
        {
            // TODO
        }
    }
}
