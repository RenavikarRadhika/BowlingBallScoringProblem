﻿using System;

namespace BowlingBallScore.Shared
{
    class FrameTypeNotFound : Exception
    {
       // TODO
    }
}
