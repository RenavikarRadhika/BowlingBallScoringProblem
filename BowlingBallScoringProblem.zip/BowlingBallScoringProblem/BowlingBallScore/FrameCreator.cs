﻿using BowlingBallScore.BowlingRules;
using BowlingBallScore.Shared;
using BowlingBallScore.UserFrames;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BowlingBallScore
{
    internal class FrameCreator
    {
        private readonly IBowlingMandatoryRules _bowlingMandatoryRules;

        internal FrameCreator(IBowlingMandatoryRules bowlingMandatoryRules)
        {
            _bowlingMandatoryRules = bowlingMandatoryRules;
        }
        internal IUserFrame CreateFrame(int frameNumber, IEnumerable<int> pins)
        {
            FrameType frameType = _bowlingMandatoryRules.GetFrameType(pins);

            switch (frameType)
            {
                case FrameType.Open:
                    return new OpenUserFrame(frameNumber, pins);

                case FrameType.Spare:
                    return new SpareUserFrame(_bowlingMandatoryRules, frameNumber, pins);

                case FrameType.Strike:
                    return new StrikeUserFrame(_bowlingMandatoryRules, frameNumber, pins);

                default:
                    throw new FrameTypeNotFound();
            }
        }
        internal void SetNextFrameOfPreviousFrame(List<IUserFrame> frames, IUserFrame frame)
        {
            if (frame == null || frames == null)
                return;

            if (frames.LastOrDefault() == null)
                return;

            frames.Last().SucceedingFrame = frame;
        }
    }
}
