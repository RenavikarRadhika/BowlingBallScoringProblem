﻿using BowlingBallScore.BowlingRules;
using BowlingBallScore.Shared;
using BowlingBallScore.UserFrames;
using System;
using System.Collections.Generic;

namespace BowlingBallScore
{
    public class BowlingGame
    {
        private readonly IBowlingMandatoryRules _bowlingMandatoryRules;

        private readonly FrameCreator _frameCreator;

        private List<IUserFrame> _frames;

        private List<int> _tempPinsForCurrentFrame;

        private int _frameCounter = 1;

        private int _rollCounterForCurrentFrame = 1;

        public BowlingGame(IBowlingMandatoryRules bowlingMandatoryRules)
        {
            _bowlingMandatoryRules = new BowlingMandatoryRules();
            _frameCreator = new FrameCreator(bowlingMandatoryRules);
            _frames = new List<IUserFrame>(_bowlingMandatoryRules.MaxFramesCount);
            _tempPinsForCurrentFrame = new List<int>();
        }

        public void PinsDownInCurrentRoll(int pins)
        {
            _tempPinsForCurrentFrame.Add(pins);

            if (_rollCounterForCurrentFrame == _bowlingMandatoryRules.GetMaxpinsDownAllowedForCurrentFrame(_frameCounter, _tempPinsForCurrentFrame))
            {
                var frame = _frameCreator.CreateFrame(_frameCounter, _tempPinsForCurrentFrame);

                _frameCreator.SetNextFrameOfPreviousFrame(_frames, frame);

                _frames.Add(frame);

                ConfigureCountersForNextFrame();
            }
            else
                _rollCounterForCurrentFrame++;
        }
        private void ConfigureCountersForNextFrame()
        {
            _frameCounter++;
            _rollCounterForCurrentFrame = 1;
            _tempPinsForCurrentFrame = new List<int>();
        }
        public int GetScore()
        {
            try
            {
                int score = 0;
                foreach (var frame in _frames)
                {
                    score += frame.GetGrossFrameScore();
                }
                return score;
            }
            catch (Exception ex)
            {
                LoggerManager.getInstace.LogException("Exception logged" + ex.Message);
                return -1;
            }
        }
    }
}
